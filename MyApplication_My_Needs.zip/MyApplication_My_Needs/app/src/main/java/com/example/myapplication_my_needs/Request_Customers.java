package com.example.myapplication_my_needs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Request_Customers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request__customers);
    }
}
