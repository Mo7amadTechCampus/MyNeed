package com.example.myapplication_my_needs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Providers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_providers);
    }

    public void SaveInfo(View view) {
    }
}
